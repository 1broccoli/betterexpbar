# repute
Tracks reputation gained and is printed in chat




![image](https://github.com/user-attachments/assets/fcc4da0d-a97c-46b6-8cd5-ec82fab746be)

![reputex](https://github.com/user-attachments/assets/c3531564-c505-4c4d-af53-e7e813e0cc46)


